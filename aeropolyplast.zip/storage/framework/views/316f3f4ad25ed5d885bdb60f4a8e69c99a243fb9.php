<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- CUSTOM JS -->
    <!-- <script src="<?php echo e(asset('js/admin/sidebar.js')); ?>" defer></script> -->


    <!-- JQUERY -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>


    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <script src="https://kit.fontawesome.com/1d264cf014.js" crossorigin="anonymous"></script>




    <!-- ajax and shit -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>



<body>

    <link rel="stylesheet" href="https://cdn.lineicons.com/2.0/LineIcons.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Hind+Vadodara:wght@300;500&display=swap" rel="stylesheet">


    <!-- LOGO NAVBAR -->
    <div class="logo-container">
        <img src="/images/logo.png">
    </div>

    <nav class="main-navbar navbar navbar-expand-lg navbar-light bg-light">

        <a class="navbar-brand" href="/"><img class="navbar-brand-image" src="/images/logo-white.png"></a>

        <button class="navbar-toggler dropdown-button" type="button" data-toggle="collapse"
            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
            aria-label="Toggle navigation">
            <span><i class="fas fa-bars"></i></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a href="<?php echo e(route('home', app()->getLocale())); ?>" class="nav-link">
                        <?php echo e(__('HOME')); ?>

                    </a>
                </li>


                <li class="nav-item">
                    <a href="<?php echo e(route('references', app()->getLocale())); ?>" class="nav-link">
                        <?php echo e(__('REFERENCES')); ?>

                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route('aboutUs', app()->getLocale())); ?>" class="nav-link">
                        <?php echo e(__('ABOUTUS')); ?>

                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route('contact', app()->getLocale())); ?>" class="nav-link">

                        <?php echo e(__('CONTACT')); ?>

                    </a>
                </li>
            </ul>

            <div class="language-container my-2 my-lg-0">

                <!-- SI -->
                <a href="<?php echo e(route(Route::currentRouteName(), 'si')); ?>">
                    <div class="language-box" id="slovenian"></div>
                </a>

                <!-- EN -->
                <a href="<?php echo e(route(Route::currentRouteName(), 'en')); ?>">
                    <div class="language-box" id="english"></div>
                </a>

                <!-- DE -->
                <a href="<?php echo e(route(Route::currentRouteName(), 'de')); ?>">
                    <div class="language-box" id="german"></div>
                </a>

                <!-- HR -->
                <a href="<?php echo e(route(Route::currentRouteName(), 'hr')); ?>">
                    <div class="language-box" id="croatian"></div>
                </a>
            </div>
        </div>
    </nav>



    <?php echo $__env->yieldContent('content'); ?>

    <?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
</body>

</html>
<?php /**PATH C:\Users\vela\Desktop\aero-polyplast\aero-web\resources\views/layouts/mainLayout.blade.php ENDPATH**/ ?>