<?php $__env->startSection('content'); ?>


    <!-- HERO IMAGE AND TEXT -->
    <div class="hero-container">

        <h2 class="hero-heading"><?php echo e(__('homeH1')); ?></h2>


        <div class="row hero-wrapper">
            <div class="hero-text-wrapper col">
                <p class="hero-text"><?php echo e(__('homeP1')); ?></p>
            </div>

            <div class="hero-image-wrapper col">
                <img src="images/material-images/hero-image.jpg" class="hero-image">
            </div>
        </div>
    </div>


    <h2 class="big-heading"> <?php echo e(__('homeh2')); ?> </h2>


    <!-- STEPS -->
    <div class="steps-container">

        <!-- 1. IDEJA -->
        <div class="step">
            <div class="step-heading">
                <span class="step-heading-text">1. <?php echo e(__('step1heading')); ?></span>
                <img src="/images/icons/idea.png" class="step-heading-icon">
            </div>
            <div class="step-text-wrapper">
                <p class="step-text"><?php echo e(__('step1text')); ?></p>
            </div>
        </div>

        <div class="step-arrow">
            <img src="/images/icons/arrow.png">
        </div>

        <!-- 2. ZASNOVA -->
        <div class="step">
            <div class="step-heading">
                <span class="step-heading-text">2. <?php echo e(__('step2heading')); ?></span>
                <img src="/images/icons/pencil.png" class="step-heading-icon">
            </div>
            <div class="step-text-wrapper">
                <p class="step-text"><?php echo e(__('step2text')); ?></p>
            </div>
        </div>

        <div class="step-arrow">
            <img src="/images/icons/arrow.png">
        </div>

        <!-- 3. IZVEDBA -->
        <div class="step">
            <div class="step-heading">
                <span class="step-heading-text">3. <?php echo e(__('step3heading')); ?></span>
                <img src="/images/icons/water.png" class="step-heading-icon">
            </div>
            <div class="step-text-wrapper">
                <p class="step-text"><?php echo e(__('step3text')); ?></p>
            </div>
        </div>

        <div class="step-arrow">
            <img src="/images/icons/arrow.png">
        </div>

        <div class="step">
            <a href="<?php echo e(route('contact', app()->getLocale())); ?>">
                <button class="contact-us-button"><?php echo e(__('contact')); ?></button>
            </a>
        </div>

    </div>


    <?php if (isset($component)) { $__componentOriginalee55c72961c76a50132d12384c2b76795f3ea227 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Partners::class, []); ?>
<?php $component->withName('partners'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalee55c72961c76a50132d12384c2b76795f3ea227)): ?>
<?php $component = $__componentOriginalee55c72961c76a50132d12384c2b76795f3ea227; ?>
<?php unset($__componentOriginalee55c72961c76a50132d12384c2b76795f3ea227); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vela\Desktop\aero-polyplast\aero-web\resources\views/home.blade.php ENDPATH**/ ?>