<div class="partners-container">
    <h2 class="partners-heading">{{ __('partners') }}</h2>

    <div class="parners-row row">

        <a href="https://lek.si/sl/zdravila-izdelki/brez-recepta/operil-05-kapljice/"><img src="/images/partners/lk.png"
                class="partner-image"></a>
        <a href="https://www.fitoval-formula.com/si/"><img src="/images/partners/krka.png" class="partner-image"></a>
        <a href="https://webshop.afroditacosmetics.com/slo/"><img src="/images/partners/afrodita.svg"
                class="partner-image"></a>
        <a href="https://www.ilirija.si/sl/?id=119"><img src="/images/partners/ilirija.png" class="partner-image"></a>
        <a href="https://www.frapak.com/en/"><img src="/images/partners/frapak.png" class="partner-image"></a>
    </div>

</div>
