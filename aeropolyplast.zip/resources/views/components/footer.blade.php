<footer id="footer">
    <div class="footer-logo-container">
        <img src="/images/logo.png">
    </div>

    <p class="footer-text">Aero - Polyplast d.o.o.</p>
    <p class="footer-text">Puchova ulica 2, 1235 Radomlje</p>
    <p class="footer-text">Telefon: 01 200 27 80</p>


    <p class="author">Created by: <a href="http://sadmir-hasanic.com/">Sadmir Hasanic</a></p>
</footer>
